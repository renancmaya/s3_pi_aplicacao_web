import ItemRepository from './classes/models/ItemRepository.js'
import CategoryRepository from './classes/models/CategoryRepository.js'
import Mapper from './classes/models/mapper.js'
import SettingsService from './classes/models/SettingsService.js'
import ToolbarView from './classes/views/ToolbarView.js'
import FormView from './classes/views/FormView.js'
import TableView from './classes/views/TableView.js'
import FilterView from './classes/views/FilterView.js'
import FilterService from './classes/models/FilterService.js'
import SortService from './classes/models/SortService.js'
import AppController from './classes/controllers/AppController.js'

const itemRepository = new ItemRepository();
const categoryRepository = new CategoryRepository();
const mapper = new Mapper();
const settings = new SettingsService();
const toolbar = new ToolbarView();
const form = new FormView();
const table = new TableView();
const filterForm = new FilterView();
const filterService = new FilterService();
const sortService = new SortService();
const controller = new AppController(itemRepository, categoryRepository, mapper, settings, toolbar, form, table, filterForm, filterService, sortService);

controller.init();