
export const mockData = [
  // ==========================================
  // SETEMBRO DE 2026
  // ==========================================

  {
    id: 1,
    description: "Salário mensal",
    type: "entrada",
    category: "salario",
    dueDate: "2026-09-05",
    paymentDate: "2026-09-05",
    value: 6500.00,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    installment: null,
    account: "Conta principal",
    notes: "Salário referente ao mês de setembro"
  },
  {
    id: 2,
    description: "Aluguel residencial",
    type: "saida",
    category: "aluguel",
    dueDate: "2026-09-10",
    paymentDate: "2026-09-09",
    value: -1800.00,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    installment: null,
    account: "Conta principal"
  },
  {
    id: 3,
    description: "Energia elétrica",
    type: "saida",
    category: "contas",
    dueDate: "2026-09-12",
    paymentDate: "2026-09-12",
    value: -215.80,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    installment: null,
    account: "Conta principal"
  },
  {
    id: 4,
    description: "Internet residencial",
    type: "saida",
    category: "internet",
    dueDate: "2026-09-15",
    paymentDate: "2026-09-14",
    value: -119.90,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    installment: null,
    account: "Cartão Nubank"
  },
  {
    id: 5,
    description: "Projeto de desenvolvimento web",
    type: "entrada",
    category: "renda-extra",
    dueDate: "2026-09-16",
    paymentDate: "2026-09-16",
    value: 1850.00,
    status: "realizado",
    recurring: false,
    account: "Conta principal",
    notes: "Desenvolvimento de landing page"
  },
  {
    id: 6,
    description: "Supermercado",
    type: "saida",
    category: "supermercado",
    dueDate: "2026-09-17",
    paymentDate: "2026-09-17",
    value: -635.40,
    status: "realizado",
    recurring: false,
    account: "Cartão Nubank"
  },
  {
    id: 7,
    description: "Academia",
    type: "saida",
    category: "academia",
    dueDate: "2026-09-18",
    paymentDate: "2026-09-18",
    value: -99.90,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Cartão Nubank"
  },
  {
    id: 8,
    description: "Plano de saúde",
    type: "saida",
    category: "saude",
    dueDate: "2026-09-20",
    paymentDate: "2026-09-19",
    value: -520.00,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 9,
    description: "Compra de cadeira ergonômica",
    type: "saida",
    category: "moveis",
    dueDate: "2026-09-21",
    paymentDate: "2026-09-21",
    value: -349.90,
    status: "realizado",
    recurring: false,
    installment: {
      current: 1,
      total: 3,
      groupId: "chair-2026"
    },
    account: "Cartão Nubank"
  },
  {
    id: 10,
    description: "Netflix",
    type: "saida",
    category: "lazer",
    dueDate: "2026-09-22",
    paymentDate: "2026-09-22",
    value: -39.90,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Cartão Nubank"
  },
  {
    id: 11,
    description: "Combustível",
    type: "saida",
    category: "combustivel",
    dueDate: "2026-09-23",
    paymentDate: "2026-09-23",
    value: -280.00,
    status: "realizado",
    recurring: false,
    account: "Cartão Nubank"
  },
  {
    id: 12,
    description: "Dividendos de investimentos",
    type: "entrada",
    category: "rendimentos",
    dueDate: "2026-09-25",
    paymentDate: "2026-09-25",
    value: 185.75,
    status: "realizado",
    recurring: false,
    account: "Conta investimentos"
  },
  {
    id: 13,
    description: "Consulta odontológica",
    type: "saida",
    category: "saude",
    dueDate: "2026-09-26",
    paymentDate: "2026-09-26",
    value: -180.00,
    status: "realizado",
    recurring: false,
    account: "Conta principal"
  },
  {
    id: 14,
    description: "Compra de livros",
    type: "saida",
    category: "cursos",
    dueDate: "2026-09-27",
    paymentDate: "2026-09-27",
    value: -145.90,
    status: "realizado",
    recurring: false,
    account: "Cartão Nubank"
  },
  {
    id: 15,
    description: "Manutenção preventiva do veículo",
    type: "saida",
    category: "manutencao",
    dueDate: "2026-09-28",
    paymentDate: "2026-09-28",
    value: -450.00,
    status: "realizado",
    recurring: false,
    account: "Conta principal"
  },

  // ==========================================
  // OUTUBRO DE 2026
  // ==========================================

  {
    id: 16,
    description: "Salário mensal",
    type: "entrada",
    category: "salario",
    dueDate: "2026-10-05",
    paymentDate: "2026-10-05",
    value: 6500.00,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 17,
    description: "Aluguel residencial",
    type: "saida",
    category: "aluguel",
    dueDate: "2026-10-10",
    paymentDate: "2026-10-10",
    value: -1800.00,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 18,
    description: "Condomínio",
    type: "saida",
    category: "contas",
    dueDate: "2026-10-10",
    paymentDate: "2026-10-09",
    value: -420.00,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 19,
    description: "Conta de água",
    type: "saida",
    category: "contas",
    dueDate: "2026-10-12",
    paymentDate: "2026-10-12",
    value: -108.50,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 20,
    description: "Energia elétrica",
    type: "saida",
    category: "contas",
    dueDate: "2026-10-13",
    paymentDate: "2026-10-13",
    value: -198.70,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 21,
    description: "Desenvolvimento de sistema administrativo",
    type: "entrada",
    category: "renda-extra",
    dueDate: "2026-10-14",
    paymentDate: "2026-10-14",
    value: 2400.00,
    status: "realizado",
    recurring: false,
    account: "Conta principal"
  },
  {
    id: 22,
    description: "Supermercado - primeira quinzena",
    type: "saida",
    category: "supermercado",
    dueDate: "2026-10-15",
    paymentDate: "2026-10-15",
    value: -385.60,
    status: "realizado",
    recurring: false,
    account: "Cartão Nubank"
  },
  {
    id: 23,
    description: "Plano de celular",
    type: "saida",
    category: "internet",
    dueDate: "2026-10-16",
    paymentDate: "2026-10-16",
    value: -65.00,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Cartão Nubank"
  },
  {
    id: 24,
    description: "Cadeira ergonômica - parcela 2/3",
    type: "saida",
    category: "moveis",
    dueDate: "2026-10-18",
    paymentDate: "2026-10-18",
    value: -349.90,
    status: "realizado",
    recurring: false,
    installment: {
      current: 2,
      total: 3,
      groupId: "chair-2026"
    },
    account: "Cartão Nubank"
  },
  {
    id: 25,
    description: "Assinatura Adobe Creative Cloud",
    type: "saida",
    category: "softwares",
    dueDate: "2026-10-19",
    paymentDate: "2026-10-19",
    value: -124.90,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Cartão Nubank"
  },
  {
    id: 26,
    description: "Academia",
    type: "saida",
    category: "academia",
    dueDate: "2026-10-20",
    paymentDate: "2026-10-20",
    value: -99.90,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Cartão Nubank"
  },
  {
    id: 27,
    description: "Combustível",
    type: "saida",
    category: "combustivel",
    dueDate: "2026-10-21",
    paymentDate: "2026-10-21",
    value: -310.00,
    status: "realizado",
    recurring: false,
    account: "Cartão Nubank"
  },
  {
    id: 28,
    description: "Compra de cadeira ergonômica - parcela 3/3",
    type: "saida",
    category: "moveis",
    dueDate: "2026-10-22",
    paymentDate: "2026-10-22",
    value: -349.90,
    status: "realizado",
    recurring: false,
    installment: {
      current: 3,
      total: 3,
      groupId: "chair-2026"
    },
    account: "Cartão Nubank"
  },
  {
    id: 29,
    description: "Plano de saúde",
    type: "saida",
    category: "saude",
    dueDate: "2026-10-23",
    paymentDate: "2026-10-23",
    value: -520.00,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 30,
    description: "Cinema e jantar",
    type: "saida",
    category: "lazer",
    dueDate: "2026-10-25",
    paymentDate: "2026-10-25",
    value: -185.00,
    status: "realizado",
    recurring: false,
    account: "Cartão Nubank"
  },

  // ==========================================
  // NOVEMBRO DE 2026
  // ==========================================

  {
    id: 31,
    description: "Salário mensal",
    type: "entrada",
    category: "salario",
    dueDate: "2026-11-05",
    paymentDate: "2026-11-05",
    value: 6500.00,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 32,
    description: "Aluguel residencial",
    type: "saida",
    category: "aluguel",
    dueDate: "2026-11-10",
    paymentDate: "2026-11-10",
    value: -1800.00,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 33,
    description: "Condomínio",
    type: "saida",
    category: "contas",
    dueDate: "2026-11-10",
    paymentDate: "2026-11-10",
    value: -420.00,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 34,
    description: "Energia elétrica",
    type: "saida",
    category: "contas",
    dueDate: "2026-11-12",
    paymentDate: "2026-11-12",
    value: -225.40,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 35,
    description: "Projeto de identidade visual",
    type: "entrada",
    category: "renda-extra",
    dueDate: "2026-11-13",
    paymentDate: "2026-11-13",
    value: 1750.00,
    status: "realizado",
    recurring: false,
    account: "Conta principal"
  },
  {
    id: 36,
    description: "Supermercado",
    type: "saida",
    category: "supermercado",
    dueDate: "2026-11-15",
    paymentDate: "2026-11-15",
    value: -580.35,
    status: "realizado",
    recurring: false,
    account: "Cartão Nubank"
  },
  {
    id: 37,
    description: "Internet residencial",
    type: "saida",
    category: "internet",
    dueDate: "2026-11-16",
    paymentDate: "2026-11-16",
    value: -119.90,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 38,
    description: "Adobe Creative Cloud",
    type: "saida",
    category: "softwares",
    dueDate: "2026-11-19",
    paymentDate: "2026-11-19",
    value: -124.90,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Cartão Nubank"
  },
  {
    id: 39,
    description: "Academia",
    type: "saida",
    category: "academia",
    dueDate: "2026-11-20",
    paymentDate: "2026-11-20",
    value: -99.90,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Cartão Nubank"
  },
  {
    id: 40,
    description: "Plano de saúde",
    type: "saida",
    category: "saude",
    dueDate: "2026-11-23",
    paymentDate: "2026-11-23",
    value: -520.00,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 41,
    description: "Rendimento de CDB",
    type: "entrada",
    category: "rendimentos",
    dueDate: "2026-11-25",
    paymentDate: "2026-11-25",
    value: 235.80,
    status: "realizado",
    recurring: false,
    account: "Conta investimentos"
  },
  {
    id: 42,
    description: "Combustível",
    type: "saida",
    category: "combustivel",
    dueDate: "2026-11-26",
    paymentDate: "2026-11-26",
    value: -295.00,
    status: "realizado",
    recurring: false,
    account: "Cartão Nubank"
  },
  {
    id: 43,
    description: "Restaurante",
    type: "saida",
    category: "lazer",
    dueDate: "2026-11-28",
    paymentDate: "2026-11-28",
    value: -165.00,
    status: "realizado",
    recurring: false,
    account: "Cartão Nubank"
  },
  {
    id: 44,
    description: "Compra de ração para cachorro",
    type: "saida",
    category: "pets",
    dueDate: "2026-11-29",
    paymentDate: "2026-11-29",
    value: -145.90,
    status: "realizado",
    recurring: false,
    account: "Cartão Nubank"
  },
  {
    id: 45,
    description: "Venda de equipamento usado",
    type: "entrada",
    category: "renda-extra",
    dueDate: "2026-11-30",
    paymentDate: "2026-11-30",
    value: 750.00,
    status: "realizado",
    recurring: false,
    account: "Conta principal"
  },

  // ==========================================
  // DEZEMBRO DE 2026
  // ==========================================

  {
    id: 46,
    description: "Salário mensal",
    type: "entrada",
    category: "salario",
    dueDate: "2026-12-05",
    paymentDate: "2026-12-05",
    value: 6500.00,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 47,
    description: "Décimo terceiro salário",
    type: "entrada",
    category: "salario",
    dueDate: "2026-12-10",
    paymentDate: "2026-12-10",
    value: 3250.00,
    status: "realizado",
    recurring: false,
    account: "Conta principal"
  },
  {
    id: 48,
    description: "Aluguel residencial",
    type: "saida",
    category: "aluguel",
    dueDate: "2026-12-10",
    paymentDate: "2026-12-10",
    value: -1800.00,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 49,
    description: "Condomínio",
    type: "saida",
    category: "contas",
    dueDate: "2026-12-10",
    paymentDate: "2026-12-10",
    value: -420.00,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 50,
    description: "Presentes de Natal",
    type: "saida",
    category: "lazer",
    dueDate: "2026-12-15",
    paymentDate: "2026-12-15",
    value: -680.00,
    status: "realizado",
    recurring: false,
    account: "Cartão Nubank"
  },
  {
    id: 51,
    description: "Supermercado - compras de Natal",
    type: "saida",
    category: "supermercado",
    dueDate: "2026-12-18",
    paymentDate: "2026-12-18",
    value: -850.00,
    status: "realizado",
    recurring: false,
    account: "Cartão Nubank"
  },
  {
    id: 52,
    description: "Viagem de fim de ano - hospedagem",
    type: "saida",
    category: "lazer",
    dueDate: "2026-12-20",
    paymentDate: "2026-12-20",
    value: -950.00,
    status: "realizado",
    recurring: false,
    account: "Cartão Nubank"
  },
  {
    id: 53,
    description: "Adobe Creative Cloud",
    type: "saida",
    category: "softwares",
    dueDate: "2026-12-19",
    paymentDate: "2026-12-19",
    value: -124.90,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Cartão Nubank"
  },
  {
    id: 54,
    description: "Plano de saúde",
    type: "saida",
    category: "saude",
    dueDate: "2026-12-23",
    paymentDate: "2026-12-23",
    value: -520.00,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 55,
    description: "Rendimento de investimentos",
    type: "entrada",
    category: "rendimentos",
    dueDate: "2026-12-25",
    paymentDate: "2026-12-25",
    value: 265.40,
    status: "realizado",
    recurring: false,
    account: "Conta investimentos"
  },
  {
    id: 56,
    description: "Conta de energia",
    type: "saida",
    category: "contas",
    dueDate: "2026-12-26",
    paymentDate: "2026-12-26",
    value: -245.70,
    status: "realizado",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 57,
    description: "Combustível",
    type: "saida",
    category: "combustivel",
    dueDate: "2026-12-27",
    paymentDate: "2026-12-27",
    value: -320.00,
    status: "realizado",
    recurring: false,
    account: "Cartão Nubank"
  },
  {
    id: 58,
    description: "Ceia de Ano Novo",
    type: "saida",
    category: "alimentacao",
    dueDate: "2026-12-29",
    paymentDate: "2026-12-29",
    value: -390.00,
    status: "realizado",
    recurring: false,
    account: "Cartão Nubank"
  },
  {
    id: 59,
    description: "Projeto freelance de dezembro",
    type: "entrada",
    category: "renda-extra",
    dueDate: "2026-12-30",
    paymentDate: "2026-12-30",
    value: 1200.00,
    status: "realizado",
    recurring: false,
    account: "Conta principal"
  },
  {
    id: 60,
    description: "Seguro residencial",
    type: "saida",
    category: "contas",
    dueDate: "2026-12-31",
    paymentDate: null,
    value: -189.90,
    status: "pendente",
    recurring: false,
    account: "Conta principal"
  },

  // ==========================================
  // JANEIRO DE 2027
  // ==========================================

  {
    id: 61,
    description: "Salário mensal",
    type: "entrada",
    category: "salario",
    dueDate: "2027-01-05",
    paymentDate: null,
    value: 6800.00,
    status: "pendente",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 62,
    description: "Aluguel residencial",
    type: "saida",
    category: "aluguel",
    dueDate: "2027-01-10",
    paymentDate: null,
    value: -1800.00,
    status: "pendente",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 63,
    description: "Condomínio",
    type: "saida",
    category: "contas",
    dueDate: "2027-01-10",
    paymentDate: null,
    value: -420.00,
    status: "pendente",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 64,
    description: "IPTU - primeira parcela",
    type: "saida",
    category: "impostos",
    dueDate: "2027-01-12",
    paymentDate: null,
    value: -280.00,
    status: "pendente",
    recurring: false,
    installment: {
      current: 1,
      total: 5,
      groupId: "iptu-2027"
    },
    account: "Conta principal"
  },
  {
    id: 65,
    description: "Energia elétrica",
    type: "saida",
    category: "contas",
    dueDate: "2027-01-13",
    paymentDate: null,
    value: -210.00,
    status: "pendente",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 66,
    description: "Supermercado",
    type: "saida",
    category: "supermercado",
    dueDate: "2027-01-15",
    paymentDate: null,
    value: -620.00,
    status: "pendente",
    recurring: false,
    account: "Cartão Nubank"
  },
  {
    id: 67,
    description: "Plano de celular",
    type: "saida",
    category: "internet",
    dueDate: "2027-01-16",
    paymentDate: null,
    value: -65.00,
    status: "pendente",
    recurring: true,
    recurrence: "monthly",
    account: "Cartão Nubank"
  },
  {
    id: 68,
    description: "Adobe Creative Cloud",
    type: "saida",
    category: "softwares",
    dueDate: "2027-01-19",
    paymentDate: null,
    value: -124.90,
    status: "pendente",
    recurring: true,
    recurrence: "monthly",
    account: "Cartão Nubank"
  },
  {
    id: 69,
    description: "Academia",
    type: "saida",
    category: "academia",
    dueDate: "2027-01-20",
    paymentDate: null,
    value: -99.90,
    status: "pendente",
    recurring: true,
    recurrence: "monthly",
    account: "Cartão Nubank"
  },
  {
    id: 70,
    description: "IPTU - segunda parcela",
    type: "saida",
    category: "impostos",
    dueDate: "2027-01-22",
    paymentDate: null,
    value: -280.00,
    status: "pendente",
    recurring: false,
    installment: {
      current: 2,
      total: 5,
      groupId: "iptu-2027"
    },
    account: "Conta principal"
  },
  {
    id: 71,
    description: "Plano de saúde",
    type: "saida",
    category: "saude",
    dueDate: "2027-01-23",
    paymentDate: null,
    value: -540.00,
    status: "pendente",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 72,
    description: "Rendimento de investimentos",
    type: "entrada",
    category: "rendimentos",
    dueDate: "2027-01-25",
    paymentDate: null,
    value: 290.50,
    status: "pendente",
    recurring: false,
    account: "Conta investimentos"
  },
  {
    id: 73,
    description: "Combustível",
    type: "saida",
    category: "combustivel",
    dueDate: "2027-01-26",
    paymentDate: null,
    value: -310.00,
    status: "pendente",
    recurring: false,
    account: "Cartão Nubank"
  },
  {
    id: 74,
    description: "Manutenção do computador",
    type: "saida",
    category: "manutencao",
    dueDate: "2027-01-27",
    paymentDate: null,
    value: -280.00,
    status: "pendente",
    recurring: false,
    account: "Conta principal"
  },
  {
    id: 75,
    description: "Projeto de design freelancer",
    type: "entrada",
    category: "renda-extra",
    dueDate: "2027-01-30",
    paymentDate: null,
    value: 1950.00,
    status: "pendente",
    recurring: false,
    account: "Conta principal"
  },

  // ==========================================
  // FEVEREIRO DE 2027
  // ==========================================

  {
    id: 76,
    description: "Salário mensal",
    type: "entrada",
    category: "salario",
    dueDate: "2027-02-05",
    paymentDate: null,
    value: 6800.00,
    status: "pendente",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 77,
    description: "Aluguel residencial",
    type: "saida",
    category: "aluguel",
    dueDate: "2027-02-10",
    paymentDate: null,
    value: -1800.00,
    status: "pendente",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 78,
    description: "Condomínio",
    type: "saida",
    category: "contas",
    dueDate: "2027-02-10",
    paymentDate: null,
    value: -420.00,
    status: "pendente",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 79,
    description: "IPTU - terceira parcela",
    type: "saida",
    category: "impostos",
    dueDate: "2027-02-12",
    paymentDate: null,
    value: -280.00,
    status: "pendente",
    recurring: false,
    installment: {
      current: 3,
      total: 5,
      groupId: "iptu-2027"
    },
    account: "Conta principal"
  },
  {
    id: 80,
    description: "Supermercado",
    type: "saida",
    category: "supermercado",
    dueDate: "2027-02-15",
    paymentDate: null,
    value: -590.00,
    status: "pendente",
    recurring: false,
    account: "Cartão Nubank"
  },
  {
    id: 81,
    description: "Internet residencial",
    type: "saida",
    category: "internet",
    dueDate: "2027-02-16",
    paymentDate: null,
    value: -119.90,
    status: "pendente",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 82,
    description: "Adobe Creative Cloud",
    type: "saida",
    category: "softwares",
    dueDate: "2027-02-19",
    paymentDate: null,
    value: -124.90,
    status: "pendente",
    recurring: true,
    recurrence: "monthly",
    account: "Cartão Nubank"
  },
  {
    id: 83,
    description: "Academia",
    type: "saida",
    category: "academia",
    dueDate: "2027-02-20",
    paymentDate: null,
    value: -99.90,
    status: "pendente",
    recurring: true,
    recurrence: "monthly",
    account: "Cartão Nubank"
  },
  {
    id: 84,
    description: "Plano de saúde",
    type: "saida",
    category: "saude",
    dueDate: "2027-02-23",
    paymentDate: null,
    value: -540.00,
    status: "pendente",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 85,
    description: "Rendimento de investimentos",
    type: "entrada",
    category: "rendimentos",
    dueDate: "2027-02-25",
    paymentDate: null,
    value: 310.80,
    status: "pendente",
    recurring: false,
    account: "Conta investimentos"
  },
  {
    id: 86,
    description: "IPTU - quarta parcela",
    type: "saida",
    category: "impostos",
    dueDate: "2027-02-26",
    paymentDate: null,
    value: -280.00,
    status: "pendente",
    recurring: false,
    installment: {
      current: 4,
      total: 5,
      groupId: "iptu-2027"
    },
    account: "Conta principal"
  },

  // ==========================================
  // LANÇAMENTOS ATRASADOS
  // ==========================================

  {
    id: 87,
    description: "Fatura de cartão de crédito",
    type: "saida",
    category: "dividas",
    dueDate: "2026-11-05",
    paymentDate: null,
    value: -780.45,
    status: "atrasado",
    recurring: false,
    account: "Cartão Nubank",
    notes: "Pagamento pendente"
  },
  {
    id: 88,
    description: "Consulta veterinária",
    type: "saida",
    category: "pets",
    dueDate: "2026-11-06",
    paymentDate: null,
    value: -220.00,
    status: "atrasado",
    recurring: false,
    account: "Conta principal"
  },
  {
    id: 89,
    description: "Conta de água",
    type: "saida",
    category: "contas",
    dueDate: "2026-11-07",
    paymentDate: null,
    value: -95.60,
    status: "atrasado",
    recurring: true,
    recurrence: "monthly",
    account: "Conta principal"
  },
  {
    id: 90,
    description: "Manutenção do veículo",
    type: "saida",
    category: "veiculo",
    dueDate: "2026-10-28",
    paymentDate: null,
    value: -650.00,
    status: "atrasado",
    recurring: false,
    account: "Conta principal"
  },

  // ==========================================
  // OUTRAS MOVIMENTAÇÕES
  // ==========================================

  {
    id: 91,
    description: "Venda de monitor usado",
    type: "entrada",
    category: "renda-extra",
    dueDate: "2026-10-08",
    paymentDate: "2026-10-08",
    value: 650.00,
    status: "realizado",
    recurring: false,
    account: "Conta principal"
  },
  {
    id: 92,
    description: "Compra de novo monitor",
    type: "saida",
    category: "moveis",
    dueDate: "2026-10-09",
    paymentDate: "2026-10-09",
    value: -1250.00,
    status: "realizado",
    recurring: false,
    installment: {
      current: 1,
      total: 5,
      groupId: "monitor-2026"
    },
    account: "Cartão Nubank"
  },
  {
    id: 93,
    description: "Compra de novo monitor - parcela 2/5",
    type: "saida",
    category: "moveis",
    dueDate: "2026-11-09",
    paymentDate: null,
    value: -1250.00,
    status: "pendente",
    recurring: false,
    installment: {
      current: 2,
      total: 5,
      groupId: "monitor-2026"
    },
    account: "Cartão Nubank"
  },
  {
    id: 94,
    description: "Compra de novo monitor - parcela 3/5",
    type: "saida",
    category: "moveis",
    dueDate: "2026-12-09",
    paymentDate: null,
    value: -1250.00,
    status: "pendente",
    recurring: false,
    installment: {
      current: 3,
      total: 5,
      groupId: "monitor-2026"
    },
    account: "Cartão Nubank"
  },
  {
    id: 95,
    description: "Compra de novo monitor - parcela 4/5",
    type: "saida",
    category: "moveis",
    dueDate: "2027-01-09",
    paymentDate: null,
    value: -1250.00,
    status: "pendente",
    recurring: false,
    installment: {
      current: 4,
      total: 5,
      groupId: "monitor-2026"
    },
    account: "Cartão Nubank"
  },
  {
    id: 96,
    description: "Compra de novo monitor - parcela 5/5",
    type: "saida",
    category: "moveis",
    dueDate: "2027-02-09",
    paymentDate: null,
    value: -1250.00,
    status: "pendente",
    recurring: false,
    installment: {
      current: 5,
      total: 5,
      groupId: "monitor-2026"
    },
    account: "Cartão Nubank"
  },
  {
    id: 97,
    description: "Curso avançado de JavaScript",
    type: "saida",
    category: "cursos",
    dueDate: "2026-10-30",
    paymentDate: "2026-10-30",
    value: -299.90,
    status: "realizado",
    recurring: false,
    account: "Cartão Nubank"
  },
  {
    id: 98,
    description: "Licença de software",
    type: "saida",
    category: "softwares",
    dueDate: "2026-11-30",
    paymentDate: null,
    value: -249.90,
    status: "pendente",
    recurring: true,
    recurrence: "yearly",
    account: "Cartão Nubank"
  },
  {
    id: 99,
    description: "Anúncios para projeto freelance",
    type: "saida",
    category: "anuncios",
    dueDate: "2026-11-18",
    paymentDate: "2026-11-18",
    value: -180.00,
    status: "realizado",
    recurring: false,
    account: "Conta principal"
  },
  {
    id: 100,
    description: "Faturamento de projeto freelance",
    type: "entrada",
    category: "faturamento",
    dueDate: "2026-11-25",
    paymentDate: null,
    value: 3200.00,
    status: "pendente",
    recurring: false,
    account: "Conta principal",
    notes: "Pagamento aguardando aprovação do cliente"
}
];

/*export const statusList = [
    { "id": 1, "slug": "pendente", "name": "Pendente" },
    { "id": 2, "slug": "realizado", "name": "Realizado" },
];

export const typeList = [
  { id: 1, slug: "entrada", name: "Entrada" },
  { id: 2, slug: "saida", name: "Saída" }
];*/

export const statusDict = {
  pendente: "Pendente",
  realizado: "Realizado",
};

export const typeDict = {
  entrada: "Entrada",
  saida: "Saída",
};

export const categoryList = [
  { id: 1, type: "saida", slug: "academia", name: "Academia" },
  { id: 2, type: "saida", slug: "alimentacao", name: "Alimentação" },
  { id: 3, type: "saida", slug: "aluguel", name: "Aluguel" },
  { id: 4, type: "saida", slug: "anuncios", name: "Anúncios" },
  { id: 5, type: "saida", slug: "beleza", name: "Beleza" },
  { id: 6, type: "saida", slug: "combustivel", name: "Combustível" },
  { id: 7, type: "saida", slug: "contabilidade", name: "Contabilidade" },
  { id: 8, type: "saida", slug: "contas", name: "Contas" },
  { id: 9, type: "saida", slug: "cursos", name: "Cursos" },
  { id: 10, type: "saida", slug: "dependentes", name: "Dependentes" },
  { id: 11, type: "saida", slug: "dividas", name: "Dívidas" },
  { id: 12, type: "saida", slug: "embalagens", name: "Embalagens" },
  { id: 13, type: "saida", slug: "estoque", name: "Estoque" },
  { id: 14, type: "entrada", slug: "faturamento", name: "Faturamento" },
  { id: 15, type: "saida", slug: "impostos", name: "Impostos" },
  { id: 16, type: "saida", slug: "internet", name: "Internet" },
  { id: 17, type: "saida", slug: "investimentos", name: "Investimentos" },
  { id: 18, type: "saida", slug: "lazer", name: "Lazer" },
  { id: 19, type: "saida", slug: "manutencao", name: "Manutenção" },
  { id: 20, type: "saida", slug: "moveis", name: "Móveis" },
  { id: 21, type: "saida", slug: "pets", name: "Pets" },
  { id: 22, type: "saida", slug: "pro-labore", name: "Pró-Labore" },
  { id: 23, type: "entrada", slug: "renda-extra", name: "Renda Extra" },
  { id: 24, type: "entrada", slug: "rendimentos", name: "Rendimentos" },
  { id: 25, type: "entrada", slug: "salario", name: "Salário" },
  { id: 26, type: "saida", slug: "saude", name: "Saúde" },
  { id: 27, type: "saida", slug: "softwares", name: "Softwares" },
  { id: 28, type: "saida", slug: "supermercado", name: "Supermercado" },
  { id: 29, type: "saida", slug: "tarifas", name: "Tarifas" },
  { id: 30, type: "saida", slug: "veiculo", name: "Veículo" },
  { id: 31, type: "saida", slug: "educacao", name: "Educação" },
  { id: 32, type: "saida", slug: "transporte", name: "Transporte" },
  { id: 33, type: "saida", slug: "vestuario", name: "Vestuário" },
  { id: 34, type: "saida", slug: "viagens", name: "Viagens" },
  { id: 35, type: "saida", slug: "servicos", name: "Serviços" },
  { id: 36, type: "saida", slug: "seguros", name: "Seguros" },
  { id: 37, type: "entrada", slug: "bonus", name: "Bônus" },
  { id: 38, type: "entrada", slug: "reembolso", name: "Reembolso" },
  { id: 39, type: "entrada", slug: "vendas", name: "Vendas" },
  { id: 40, type: "entrada", slug: "outros", name: "Outros recebimentos" },
  { id: 41, type: "saida", slug: "outros", name: "Outras despesas" }
]